package mapsynq_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LIVE_Tab {
	
	public static void main(String[] args) throws InterruptedException {
        //System.out.println("Hello test1");
    	System.setProperty("webdriver.gecko.driver", "C:\\Users\\SAURAV\\eclipse-workspace_Quantam\\test1\\driver\\geckodriver.exe");
    	WebDriver driver = new FirefoxDriver();
    	driver.get("http://www.mapsynq.com/");
    	
    	driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/div[1]/div/a[3]")).click();
    	
    	driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/div[6]/div[1]/label[2]/span/h2")).click();
    	Thread.sleep(3000);
    	
    	driver.findElement(By.id("txtSearchCamerasingapore")).sendKeys("bukit merah Flyover");
    	
    	driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/div[6]/div[4]/div[1]/div[3]/div[2]/ul/li[10]/div/a")).click();
    	
    		
    }

}
