package mapsynq_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtendReport {
	
	public void setupextentreport() {
		String reportpath = System.getProperty("user.dir")+"/target/ExecutionReport.html";
		ExtentSparkReporter sparkReport = new ExtentSparkReporter(reportpath);
		
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(sparkReport);
		
		ExtentTest test = extent.createTest("Register","This is to Register");
		
		test.log(Status.INFO, "Starting the TestCase");
		
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\SAURAV\\eclipse-workspace_Quantam\\test1\\driver\\geckodriver.exe");
    	WebDriver driver = new FirefoxDriver();
    	driver.get("http://www.mapsynq.com/");
    	
    	driver.findElement(By.xpath("//*[@id=\"txtGlobalSearch\"]")).sendKeys("Bukit Road");;
    	test.pass("Entered in Search Box");
    	
    	driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/form/span")).click();
    	test.fail("Unable to Search");
    	
    	test.pass("Close the Browser");
    	extent.flush();
    	
    	
    	
    	
		
		
		
		
		
		
	}
	

}
