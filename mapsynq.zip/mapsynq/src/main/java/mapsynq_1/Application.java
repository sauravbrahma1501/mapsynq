package mapsynq_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Application {

    public static void main(String[] args) {
        //System.out.println("Hello test1");
    	System.setProperty("webdriver.gecko.driver", "C:\\Users\\SAURAV\\eclipse-workspace_Quantam\\test1\\driver\\geckodriver.exe");
    	WebDriver driver = new FirefoxDriver();
    	driver.get("http://www.mapsynq.com/");
    	
    	driver.findElement(By.cssSelector("html body div#div_header div.search_bar_wrapper div.search_bar form#formPublicSearch input#txtGlobalSearch.ui-autocomplete-input.ui-autocomplete-loading")).click();
    	driver.close();
    	driver.quit();
    }

}