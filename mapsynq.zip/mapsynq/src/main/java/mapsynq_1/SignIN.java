package mapsynq_1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class SignIN {
	
	public static void main(String[] args) throws InterruptedException {
        //System.out.println("Hello test1");
    	System.setProperty("webdriver.gecko.driver", "C:\\Users\\SAURAV\\eclipse-workspace_Quantam\\test1\\driver\\geckodriver.exe");
    	WebDriver driver = new FirefoxDriver();
    	driver.get("http://www.mapsynq.com/");
    	
    	driver.findElement(By.linkText("Sign in")).click();
    	driver.findElement(By.id("name")).sendKeys("saurav.brahma");
    	driver.findElement(By.id("password")).sendKeys("saurav");
    	
    	Actions act = new Actions(driver);
    	act.sendKeys(Keys.TAB).perform();
    	
    	Thread.sleep(3000);
    	//driver.findElement(By.id("button_org")).click();
    	driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr/td/div/div/div[2]/div[1]/form/table/tbody/tr[6]/td[2]/div[1]/input")).click();
    	
    	Thread.sleep(3000);
    }

}
