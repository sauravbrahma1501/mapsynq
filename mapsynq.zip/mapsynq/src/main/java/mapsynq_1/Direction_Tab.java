package mapsynq_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Direction_Tab {
	
	public static void main(String[] args) throws InterruptedException {
        //System.out.println("Hello test1");
    	System.setProperty("webdriver.gecko.driver", "C:\\Users\\SAURAV\\eclipse-workspace_Quantam\\test1\\driver\\geckodriver.exe");
    	WebDriver driver = new FirefoxDriver();
    	driver.get("http://www.mapsynq.com/");
    	
    	driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/div[1]/div/a[1]")).click();
    	driver.findElement(By.id("poi_from")).sendKeys("");
    	
    	driver.findElement(By.id("poi_to")).sendKeys("");
    	
    	driver.findElement(By.xpath("//*[@id=\"also_shortest\"]")).click();
    	
    	Thread.sleep(4000);
    	
    	driver.findElement(By.xpath("//*[@id=\"get_direction\"]")).click();
    }

}
