package mapsynq_1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import cn.hutool.core.codec.Base64;

public class Register {
	public static void main(String[] args) throws InterruptedException {
        //System.out.println("Hello test1");
    	System.setProperty("webdriver.gecko.driver", "C:\\Users\\SAURAV\\eclipse-workspace_Quantam\\test1\\driver\\geckodriver.exe");
    	WebDriver driver = new FirefoxDriver();
    	driver.get("http://www.mapsynq.com/");
    	
    	//driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[4]/a[1]"));
    	//by link text
    	//driver.findElement(By.linkText("Register")).click();
    	//by xpath
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[4]/a[2]")).click();
    	driver.findElement(By.id("profile_first_name")).sendKeys("Saurav");
    	driver.findElement(By.id("profile_last_name")).sendKeys("Brahma ");
    	
    	WebElement element = driver.findElement(By.xpath("//select[@id='profile_country']"));
    	Select sel = new Select(element);
    	sel.selectByVisibleText("India");
    	driver.findElement(By.id("profile_address")).sendKeys("Kasba");
    	driver.findElement(By.id("profile_contact_no")).sendKeys("9874262355");
    	driver.findElement(By.xpath("//*[@id=\"profile_gender_M\"]")).click();
    	driver.findElement(By.id("profile_dob")).sendKeys("15-01-2000");
    	
    	Actions act = new Actions(driver);
    	act.sendKeys(Keys.TAB).perform();
    	
    	driver.findElement(By.xpath("//*[@id=\"profile_email\"]")).sendKeys("abc@gmail.com");
    	//driver.findElement(By.id("user_name")).sendKeys("s.brahma");
    	//driver.findElement(By.id("password")).sendKeys("SAUraV");
    	
    	driver.findElement(By.id("password")).sendKeys(decodeString("abcdefghijk"));
    	
    	driver.findElement(By.id("identity[password_confirmation]")).sendKeys("SAUraV");
    	//Thread.sleep(3000);
    	//driver.findElement(By.name("profile[subscribe_to_newsletter]")).click();
    	//driver.findElement(By.xpath("//*[@id=\"profile_subscribe_to_newsletter\"]")).click();
    	Thread.sleep(3000);
    	System.out.print("Going Right2");
    	//driver.findElement(By.xpath("//*[@id=\"chk_agree\"]")).click();
    	driver.findElement(By.id("chk_agree")).click();
    	Thread.sleep(3000);
    	
    	driver.findElement(By.name("commit")).click();
    	Thread.sleep(3000);
    	
    	
    	driver.close();
    	driver.quit();
    	
    }
	static String decodeString(String password)
	{
		byte[] decodedString = Base64.decode(password);
		return(new String(decodedString));
	}
	
	
	
}
